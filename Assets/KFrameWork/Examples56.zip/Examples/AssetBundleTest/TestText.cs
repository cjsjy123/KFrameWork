﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using KUtils;
using UnityEngine.UI;

public class TestText : MonoBehaviour {
    public Sprite tex;
    public Image img;

	// Use this for initialization
	void Start () {
        //this.transform.AddPrefab(img.gameObject);
        //img.sprite = tex;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

