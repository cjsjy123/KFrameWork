﻿using UnityEngine;
using System.Collections;
using KFrameWork;
using KUtils;

public class TestSchedule : UnityMonoBehaviour {
    
    private float _delay =0.1f;
    private float delta = 0.5f;
    private int _times =1;

    private int _delayframe = 1;
    private int deltaframe = 1;

    private bool isFrame;
	// Use this for initialization
    protected override  void Start () {
        base.Start();
	}

    void ScheduleOnce(float time)
    {
        LogMgr.LogFormat("Once定时器启动时间: {0} 当前帧数 :{1}", GameSyncCtr.mIns.FrameWorkTime, GameSyncCtr.mIns.RenderFrameCount);
        if(isFrame)
        {
            Schedule.mIns.ScheduleRepeatFrameInvoke(_delayframe,deltaframe,1,null, InvokeDone);
        }
        else
        {
            Schedule.mIns.ScheduleInvoke(time, null, InvokeDone);
        }
        
    }

    void InvokeDone(object o,int left)
    {
        LogMgr.LogFormat("当前时间为 {0} 当前帧数 :{1}", GameSyncCtr.mIns.FrameWorkTime, GameSyncCtr.mIns.RenderFrameCount);
    }

    void ScheduleMultiTimes(float delay,float delta,int times)
    {
        LogMgr.LogFormat("Multi定时器启动时间: {0} 当前帧数 :{1}", GameSyncCtr.mIns.FrameWorkTime, GameSyncCtr.mIns.RenderFrameCount);
        if (isFrame)
        {
            Schedule.mIns.ScheduleRepeatFrameInvoke(_delayframe, deltaframe, times, null, InvokeDone);
        }
        else
        {
            Schedule.mIns.ScheduleRepeatInvoke(delay, delta, times, null, InvokeDone);
        }
    }

	
	// Update is called once per frame
	void OnGUI() {

        
        isFrame = GUILayout.Toggle( isFrame, "是否为帧数模式");
        if(isFrame)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("delay frame : " + _delayframe.ToString(), GUILayout.Width(100));
            _delayframe = Mathf.RoundToInt( GUILayout.HorizontalSlider(_delayframe, 0f, 1000f, GUILayout.Width(100)));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Delta frame : " + deltaframe.ToString(), GUILayout.Width(100));
            deltaframe = Mathf.RoundToInt(GUILayout.HorizontalSlider(deltaframe, 0f, 1000f, GUILayout.Width(100)));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("invoke times : " + _times.ToString(), GUILayout.Width(100));
            _times = (int)GUILayout.HorizontalSlider((int)_times, 0f, 1000f, GUILayout.Width(100));
            GUILayout.EndHorizontal();
        }
        else
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("delay time : " + _delay.ToString(), GUILayout.Width(100));
            _delay = GUILayout.HorizontalSlider(_delay, 0f, 10f, GUILayout.Width(100));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Delta time : " + delta.ToString(), GUILayout.Width(100));
            delta = GUILayout.HorizontalSlider(delta, 0f, 10f, GUILayout.Width(100));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("invoke times : " + _times.ToString(), GUILayout.Width(100));
            _times = (int)GUILayout.HorizontalSlider((int)_times, 0f, 100f, GUILayout.Width(100));
            GUILayout.EndHorizontal();

        }
        

        if (GUILayout.Button("定时器invoke 1次"))
        {
            this.ScheduleOnce(_delay);
        }

        if(GUILayout.Button("定时器invoke 多次"))
        {
            this.ScheduleMultiTimes(_delay,delta,_times);
        }

	}
}
