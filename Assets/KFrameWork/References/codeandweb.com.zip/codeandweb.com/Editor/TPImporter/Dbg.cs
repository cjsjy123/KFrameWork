using System;
using UnityEngine;
using KFrameWork;

namespace TPImporter
{
	public class Dbg
	{
		public static bool enabled = false;

		public static void Log(string msg)
		{
			if (enabled)
			{
				Debug.Log(msg);
			}
		}
	}
}
