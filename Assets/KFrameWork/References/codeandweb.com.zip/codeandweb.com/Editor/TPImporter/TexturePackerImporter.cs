using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace TPImporter
{
	public class TexturePackerImporter : AssetPostprocessor
	{
		private static SpritesheetCollection spriteSheets = new SpritesheetCollection();

		[PreferenceItem("TexturePacker")]
		private static void PreferencesGUI()
		{
			EditorGUILayout.HelpBox("Pivot point settings can now be configured per project. Please use Edit -> Project Settings -> TexturePacker", MessageType.Info);
		}

		private static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths)
		{
			List<string> list = new List<string>(deletedAssets);
			list.AddRange(movedFromAssetPaths);
			foreach (string current in list)
			{
				if (Path.GetExtension(current).Equals(".tpsheet"))
				{
					Dbg.Log("OnPostprocessAllAssets: removing sprite sheet data " + current);
					TexturePackerImporter.spriteSheets.unloadSheetData(current);
				}
			}
			List<string> list2 = new List<string>(importedAssets);
			list2.AddRange(movedAssets);
			foreach (string current2 in list2)
			{
				if (Path.GetExtension(current2).Equals(".tpsheet"))
				{
					string str = (!SettingsDatabase.getInstance().containsDataFile(current2)) ? "adding " : "updating ";
					Dbg.Log("OnPostprocessAllAssets: " + str + " sprite sheet data " + current2);
					if (TexturePackerImporter.spriteSheets.loadSheetData(current2))
					{
						SettingsDatabase instance = SettingsDatabase.getInstance();
						string text = instance.spriteFileForDataFile(current2);
						AssetDatabase.ImportAsset(text, ImportAssetOptions.ForceUpdate);
						string text2 = instance.normalsFileForDataFile(current2);
						if (text2 != null)
						{
							AssetDatabase.ImportAsset(text2, ImportAssetOptions.ForceUpdate);
						}
					}
				}
			}
		}

		private static void GetOrigImageSize(Texture2D texture, TextureImporter importer, out int width, out int height)
		{
			try
			{
				object[] array = new object[]
				{
					0,
					0
				};
				MethodInfo method = typeof(TextureImporter).GetMethod("GetWidthAndHeight", BindingFlags.Instance | BindingFlags.NonPublic, null, new Type[]
				{
					typeof(int).MakeByRefType(),
					typeof(int).MakeByRefType()
				}, null);
				if (object.Equals(null, method))
				{
					throw new Exception("Method GetWidthAndHeight(int,int) not found");
				}
				method.Invoke(importer, array);
				width = (int)array[0];
				height = (int)array[1];
			}
			catch (Exception ex)
			{
				Debug.LogError("Invoking TextureImporter.GetWidthAndHeight() failed: " + ex.ToString());
				width = texture.width;
				height = texture.height;
			}
		}

		public void OnPostprocessTexture(Texture2D texture)
		{
			TextureImporter textureImporter = assetImporter as TextureImporter;
			int num;
			int num2;
			TexturePackerImporter.GetOrigImageSize(texture, textureImporter, out num, out num2);
			Dbg.Log(string.Concat(new object[]
			{
				"OnPostprocessTexture(",
				base.assetPath,
				"), ",
				texture.width,
				"x",
				texture.height,
				", orig:",
				num,
				"x",
				num2
			}));
			SettingsDatabase instance = SettingsDatabase.getInstance();
			if (!instance.isSpriteSheet(assetPath))
			{
				string text = Path.ChangeExtension(assetPath, ".tpsheet");
				if (File.Exists(text))
				{
					Dbg.Log("No tpsheet loaded for " + assetPath + ", loading fallback: " + text);
					if (!TexturePackerImporter.spriteSheets.loadSheetData(text))
					{
						Dbg.Log("Failed to load sprite sheet data " + text);
					}
				}
			}
			if (instance.isSpriteSheet(assetPath))
			{
				SheetInfo sheetInfo = TexturePackerImporter.spriteSheets.sheetInfoForSpriteFile(assetPath);
				if (sheetInfo.width > 0 && sheetInfo.height > 0 && (sheetInfo.width != num || sheetInfo.height != num2))
				{
                    textureImporter.spriteImportMode = SpriteImportMode.Single;
					Dbg.Log("Inconsistent sheet size in png/tpsheet");
				}
				else if (textureImporter.textureType != TextureImporterType.Sprite && textureImporter.textureType != TextureImporterType.Advanced)
				{
					Dbg.Log("Sprite has type " + textureImporter.textureType + ", re-importing it as 'Sprite'");
					textureImporter.textureType = TextureImporterType.Sprite;
					AssetDatabase.ImportAsset(base.assetPath, ImportAssetOptions.ForceUpdate);
				}
				else
				{
					TexturePackerImporter.updateSpriteMetaData(textureImporter, sheetInfo);
					Dbg.Log("Updated SpriteMetaData for " +assetPath);
				}
			}
			else if (instance.isNormalmapSheet(assetPath))
			{
				if (textureImporter.textureType != TextureImporterType.Advanced)
				{
					textureImporter.textureType = TextureImporterType.Bump;
                }
				Dbg.Log("Creating material for " + assetPath);
				TexturePackerImporter.createMaterialForNormalmap(assetPath, instance.spriteFileForNormalsFile(assetPath));
			}
			else
			{
				Dbg.Log("No tpsheet file loaded for " + assetPath + ", skipping");
			}
		}

		public void OnPostprocessSprites(Texture2D texture, Sprite[] sprites)
		{
			TexturePackerImporter.spriteSheets.assignGeometries(assetPath, sprites);
		}

		private static void updateSpriteMetaData(TextureImporter importer, SheetInfo sheetInfo)
		{
			Dbg.Log("PNG has type " + importer.textureType);
            importer.spriteImportMode = SpriteImportMode.Multiple;
			SpriteMetaData[] metadata = sheetInfo.metadata;

            SpriteMetaData[] spritesheet = importer.spritesheet;
            for (int i = 0; i < metadata.Length; i++)
            {
                SpriteMetaData[] array = spritesheet;
                for (int j = 0; j < array.Length; j++)
                {
                    SpriteMetaData spriteMetaData = array[j];
                    if (spriteMetaData.name == metadata[i].name)
                    {
                        if (!sheetInfo.pivotPointsEnabled || !SettingsDatabase.getInstance().importPivotPoints())
                        {
                            metadata[i].pivot = spriteMetaData.pivot;
                            metadata[i].alignment = spriteMetaData.alignment;
                        }
                        if (!sheetInfo.bordersEnabled)
                        {
                            metadata[i].border = spriteMetaData.border;
                        }
                        break;
                    }
                }
            }
            importer.spritesheet = metadata;
            EditorUtility.SetDirty(importer);
		}

		private static void createMaterialForNormalmap(string normalSheet, string spriteSheet)
		{
			string text = Path.ChangeExtension(spriteSheet, ".mat");
			if (!File.Exists(text))
			{
				Texture2D texture = AssetDatabase.LoadAssetAtPath(spriteSheet, typeof(Texture2D)) as Texture2D;
				Texture2D texture2D = AssetDatabase.LoadAssetAtPath(normalSheet, typeof(Texture2D)) as Texture2D;
				if (texture2D == null)
				{
					return;
				}
				bool flag = true;
				Shader shader = Shader.Find("Standard");
				if (shader == null)
				{
					shader = Shader.Find("Transparent/Bumped Diffuse");
					flag = false;
				}
				Material material = new Material(shader);
				material.SetTexture("_MainTex", texture);
				material.SetTexture("_BumpMap", texture2D);
				if (flag)
				{
					material.SetFloat("_Mode", 2f);
					material.SetInt("_SrcBlend", 5);
					material.SetInt("_DstBlend", 10);
					material.SetInt("_ZWrite", 0);
					material.DisableKeyword("_ALPHATEST_ON");
					material.EnableKeyword("_ALPHABLEND_ON");
					material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
					material.renderQueue = 3000;
				}
				AssetDatabase.CreateAsset(material, text);
				EditorUtility.SetDirty(material);
			}
		}
	}
}
